# ✅ Backend + Security Overhaul — Complete

## What Changed

| Before | After |
|---|---|
| Content in `localStorage` — wiped on cache clear | Content in `server/data/content.json` — permanent |
| Password hash bundled in browser JS bundle | bcrypt hash on server only — never sent to browser |
| Auth runs in browser — JS-patchable | Auth runs on Express — tamper-proof |
| Lockout in localStorage — clearable by anyone | Rate-limit by IP on Express (5 req/15 min) |
| `dangerouslySetInnerHTML` XSS vector in About | Safe `<strong>`/`<em>` renderer — no raw HTML |
| No content API — stale across tabs | `GET /api/content` — all tabs get same data |

---

## 🏗️ What Was Built

```
server/
├── .env                 ← bcrypt hash + JWT secret (never sent to browser)
├── index.js             ← Express API (auth + content routes)
├── middleware/
│   └── auth.js          ← JWT verification on every save
└── data/
    └── content.json     ← Persistent portfolio content
```

---

## 🔒 Security Audit — All 8 Issues Fixed

| # | Vulnerability | Status |
|---|---|---|
| 1 | Password hash in `VITE_*` env (visible in DevTools) | ✅ Moved to `server/.env` |
| 2 | Admin URL in `VITE_*` env (visible in DevTools) | ✅ Removed from client |
| 3 | Auth runs in browser (JS-patchable) | ✅ Moved to Express + bcrypt |
| 4 | Lockout in `localStorage` (clearable) | ✅ Rate-limit by IP on server |
| 5 | Content mutations had no auth | ✅ JWT required for all PUTs |
| 6 | XSS via `dangerouslySetInnerHTML` | ✅ Safe renderer (only `<strong>/<em>`) |
| 7 | Old PBKDF2 hash/salt in browser bundle | ✅ Zero secrets in JS bundle (verified) |
| 8 | No input sanitisation | ✅ Server-side sanitisation on all sections |

### Bundle Audit Result
```
✅ bcrypt hash      — NOT in browser bundle
✅ JWT secret       — NOT in browser bundle  
✅ Old PBKDF2 hash  — NOT in browser bundle
✅ deriveBits/importKey — NOT in browser bundle
```

---

## 🚀 How to Run

```bash
npm run dev   # Starts BOTH Vite (port 5174) + Express (port 3001)
```
The Vite proxy transparently forwards `/api/*` to Express — no CORS issues.

---

## 🔐 Admin Access

| | |
|---|---|
| **URL** | `http://localhost:5174/adwaith-ctrl-0x1` |
| **Password** | `J#F]RkBey3YH#*eu` |
| **Algorithm** | bcrypt (cost 12) — server-side only |
| **Session** | JWT · 15-min expiry · stored in `sessionStorage` |
| **Rate limit** | 5 failed logins per 15 minutes per IP |
| **Inactivity** | Auto-logout after 15 min of inactivity |

---

## ✅ Verified Tests

| Test | Result |
|---|---|
| `POST /api/auth/login` with correct password | ✅ Returns JWT token |
| `PUT /api/content/hero` with JWT | ✅ `{"success": true}` |
| `GET /api/content` after save | ✅ Returns updated `ADWAITH V` |
| Content in `server/data/content.json` | ✅ Persisted to disk |
| Production build `npm run build` | ✅ 0 errors |

---

## 📡 API Endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| `GET` | `/api/health` | None | Server health check |
| `GET` | `/api/content` | None | Public portfolio content |
| `POST` | `/api/auth/login` | None (rate-limited) | Get JWT token |
| `PUT` | `/api/content/hero` | JWT | Update hero section |
| `PUT` | `/api/content/about` | JWT | Update about section |
| `PUT` | `/api/content/expertise` | JWT | Update expertise cards |
| `PUT` | `/api/content/skills` | JWT | Update skills section |
| `PUT` | `/api/content/projects` | JWT | Update projects |
| `PUT` | `/api/content/footer` | JWT | Update footer links |

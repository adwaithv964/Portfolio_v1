/**
 * server/index.js — Adwaith V Portfolio API Server
 *
 * Endpoints:
 *   POST /api/auth/login       — verify password, return JWT
 *   GET  /api/content          — public content (no auth)
 *   PUT  /api/content/:section — update section (JWT required)
 *
 * Security:
 *   • bcrypt (cost 12) for password hashing
 *   • JWT HS256 (15-min expiry) for admin sessions
 *   • express-rate-limit (login: 5/15min, general: 200/15min)
 *   • helmet for HTTP security headers
 *   • Input sanitisation on all admin mutations
 *   • No sensitive secrets ever sent to client
 */

import 'dotenv/config';
import express         from 'express';
import helmet          from 'helmet';
import cors            from 'cors';
import rateLimit       from 'express-rate-limit';
import bcrypt          from 'bcrypt';
import jwt             from 'jsonwebtoken';
import fs              from 'fs';
import path            from 'path';
import { fileURLToPath } from 'url';
import { requireAuth } from './middleware/auth.js';

const __dirname  = path.dirname(fileURLToPath(import.meta.url));
const CONTENT_FILE = path.join(__dirname, 'data', 'content.json');
const PORT       = process.env.PORT || 3001;
const app        = express();

// ── Validate required env vars on startup ─────────────────────────────────────
const REQUIRED_ENV = ['ADMIN_BCRYPT_HASH', 'JWT_SECRET'];
for (const key of REQUIRED_ENV) {
  if (!process.env[key]) {
    console.error(`[Server] FATAL: Missing required env var: ${key}`);
    process.exit(1);
  }
}

// ── Security middleware ───────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc:  ["'self'"],
      styleSrc:   ["'self'", "'unsafe-inline'"],
      imgSrc:     ["'self'", 'data:'],
      connectSrc: ["'self'"],
    },
  },
}));

app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:5174',
  credentials: true,
  methods: ['GET', 'POST', 'PUT'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json({ limit: '64kb' })); // Prevent oversized body attacks

// ── Rate limiters ─────────────────────────────────────────────────────────────
// Login: max 5 attempts per 15 minutes per IP
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: 'Too many login attempts. Locked for 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true, // Only count failures
});

// General API: 200 req/15min per IP
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/', apiLimiter);

// ── Helpers ───────────────────────────────────────────────────────────────────
function readContent() {
  try {
    const raw = fs.readFileSync(CONTENT_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function writeContent(data) {
  fs.writeFileSync(CONTENT_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

// Valid section keys — prevents path traversal / arbitrary key injection
const VALID_SECTIONS = new Set(['hero', 'about', 'expertise', 'skills', 'projects', 'footer']);

// Strip all HTML tags from a string (for fields that shouldn't accept HTML)
function stripTags(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/<[^>]*>/g, '');
}

// Recursively sanitise strings that should not have HTML
// 'bio' and achievements 'text' are the only fields that allow limited HTML
function sanitiseSection(section, key, data) {
  if (key === 'hero' || key === 'footer') {
    return sanitiseObj(data, []); // No HTML in hero / footer
  }
  if (key === 'about') {
    return {
      ...sanitiseObj(data, ['bio']),
      achievements: (data.achievements || []).map(a => ({
        text: sanitiseLimitedHtml(a.text || ''),
      })),
    };
  }
  if (key === 'expertise') {
    return (data || []).map(item => sanitiseObj(item, []));
  }
  if (key === 'skills') {
    return (data || []).map(cat => ({
      ...sanitiseObj(cat, []),
      skills: (cat.skills || []).map(s => stripTags(s).slice(0, 60)),
    }));
  }
  if (key === 'projects') {
    return (data || []).map(p => ({
      ...sanitiseObj(p, []),
      tags: (p.tags || []).map(t => stripTags(t).slice(0, 60)),
    }));
  }
  return data;
}

// Sanitise all string values in an object; allowedHtmlKeys may keep HTML
function sanitiseObj(obj, allowedHtmlKeys) {
  if (typeof obj !== 'object' || obj === null) return obj;
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string') {
      out[k] = allowedHtmlKeys.includes(k) ? sanitiseLimitedHtml(v) : stripTags(v).slice(0, 1000);
    } else if (Array.isArray(v)) {
      out[k] = v.map(item => typeof item === 'string' ? stripTags(item).slice(0, 200) : item);
    } else {
      out[k] = v;
    }
  }
  return out;
}

// Allow only <strong> and <em> tags — strip everything else
function sanitiseLimitedHtml(str) {
  if (typeof str !== 'string') return '';
  // Remove all tags except <strong> and <em>
  return str
    .replace(/<(?!\/?(?:strong|em)\b)[^>]*>/gi, '')
    .slice(0, 2000);
}

// ── Routes ────────────────────────────────────────────────────────────────────

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', ts: Date.now() });
});

// ── POST /api/auth/login ──────────────────────────────────────────────────────
app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const { password } = req.body || {};

  if (typeof password !== 'string' || password.length > 256) {
    return res.status(400).json({ error: 'Invalid request.' });
  }

  try {
    const valid = await bcrypt.compare(password, process.env.ADMIN_BCRYPT_HASH);

    if (!valid) {
      // Return same error shape regardless — no info leak
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    const token = jwt.sign(
      { sub: 'admin', iat: Math.floor(Date.now() / 1000) },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '15m', algorithm: 'HS256' }
    );

    return res.json({ token });
  } catch (err) {
    console.error('[Auth] Login error:', err.message);
    return res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// ── GET /api/content ──────────────────────────────────────────────────────────
app.get('/api/content', (req, res) => {
  const content = readContent();
  if (!content) return res.status(500).json({ error: 'Content unavailable.' });
  // Strip internal _version before sending
  const { _version, ...publicContent } = content;
  res.json(publicContent);
});

// ── PUT /api/content/:section ─────────────────────────────────────────────────
app.put('/api/content/:section', requireAuth, (req, res) => {
  const { section } = req.params;

  if (!VALID_SECTIONS.has(section)) {
    return res.status(400).json({ error: `Invalid section: ${section}` });
  }

  const incoming = req.body;
  if (!incoming || typeof incoming !== 'object') {
    return res.status(400).json({ error: 'Invalid body.' });
  }

  try {
    const content  = readContent();
    if (!content)  return res.status(500).json({ error: 'Cannot read content file.' });

    const sanitised = sanitiseSection(section, section, incoming);
    content[section] = sanitised;
    writeContent(content);

    res.json({ success: true, section, data: sanitised });
  } catch (err) {
    console.error(`[Content] Write error (${section}):`, err.message);
    res.status(500).json({ error: 'Failed to save content.' });
  }
});

// ── 404 catch-all ─────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: 'Not found.' });
});

// ── Global error handler ──────────────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[Server] Unhandled error:', err.message);
  res.status(500).json({ error: 'Internal server error.' });
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅  API server running on http://localhost:${PORT}`);
  console.log(`   GET  /api/content         — public`);
  console.log(`   POST /api/auth/login      — rate-limited`);
  console.log(`   PUT  /api/content/:section — JWT protected\n`);
});

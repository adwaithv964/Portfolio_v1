import bcrypt from 'bcrypt';
import crypto from 'crypto';

const hash = await bcrypt.hash('J#F]RkBey3YH#*eu', 12);
const jwtSecret = crypto.randomBytes(64).toString('hex');
console.log('BCRYPT_HASH=' + hash);
console.log('JWT_SECRET=' + jwtSecret);

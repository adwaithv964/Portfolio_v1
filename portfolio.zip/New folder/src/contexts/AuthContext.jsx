/**
 * AuthContext.jsx — Admin authentication context
 *
 * Login flow:
 *  1. POST /api/auth/login  → server verifies bcrypt → returns JWT
 *  2. JWT stored in sessionStorage (cleared on tab close)
 *  3. Every admin save attaches: Authorization: Bearer <token>
 *  4. Server validates JWT on every mutating request
 *
 * Lockout, rate-limiting, and brute-force protection are all SERVER-SIDE.
 */

import { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { storeToken, getToken, hasSession, clearSession, authHeader } from '@/utils/adminAuth.js';

const AuthContext = createContext(null);

// Session duration in ms — after this much inactivity the client logs out
// (The JWT itself also expires server-side at 15 min)
const INACTIVITY_MS = 15 * 60 * 1000; // 15 minutes

export function AuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(() => hasSession());
  const [isLoading,       setIsLoading]       = useState(false);
  const [error,           setError]           = useState('');
  const inactivityTimer = useRef(null);

  // ── Inactivity auto-logout ────────────────────────────────────────────────
  const resetInactivityTimer = useCallback(() => {
    if (!isAuthenticated) return;
    clearTimeout(inactivityTimer.current);
    inactivityTimer.current = setTimeout(() => {
      logout('Session expired due to inactivity.');
    }, INACTIVITY_MS);
  }, [isAuthenticated]); // eslint-disable-line

  useEffect(() => {
    if (!isAuthenticated) return;
    const events = ['mousemove', 'keydown', 'click', 'scroll'];
    events.forEach(e => window.addEventListener(e, resetInactivityTimer));
    resetInactivityTimer();
    return () => {
      events.forEach(e => window.removeEventListener(e, resetInactivityTimer));
      clearTimeout(inactivityTimer.current);
    };
  }, [isAuthenticated, resetInactivityTimer]);

  // ── Login — POST to server, receive JWT ───────────────────────────────────
  const login = useCallback(async (password) => {
    setError('');
    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();

      if (res.ok && data.token) {
        storeToken(data.token);
        setIsAuthenticated(true);
        return true;
      }

      // Server returns 401 for bad password, 429 for rate-limit
      if (res.status === 429) {
        setError('Too many failed attempts. Locked for 15 minutes.');
      } else {
        setError(data.error || 'Invalid credentials.');
      }
      return false;

    } catch {
      setError('Cannot reach server. Is it running?');
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // ── Logout ────────────────────────────────────────────────────────────────
  const logout = useCallback((reason = '') => {
    clearSession();
    clearTimeout(inactivityTimer.current);
    setIsAuthenticated(false);
    if (reason) setError(reason);
  }, []);

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      isLoading,
      error,
      login,
      logout,
      setError,
      authHeader,  // expose so admin sections can attach to fetch calls
      getToken,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

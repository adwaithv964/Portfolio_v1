/**
 * adminAuth.js — Client-side JWT session manager
 *
 * All real auth (bcrypt verify, rate-limit, lockout) is now on the SERVER.
 * This module only stores/reads the JWT token from sessionStorage.
 *
 * Security properties:
 *  • sessionStorage: wiped automatically when tab/browser closes
 *  • Token expiry: enforced server-side (15 min)
 *  • No password hash, salt, or secret ever stored client-side
 */

const SESSION_KEY = 'av_admin_jwt';

// ── Store JWT returned by server ──────────────────────────────────────────────
export function storeToken(token) {
  sessionStorage.setItem(SESSION_KEY, token);
}

// ── Retrieve stored JWT ───────────────────────────────────────────────────────
export function getToken() {
  return sessionStorage.getItem(SESSION_KEY) || null;
}

// ── Check if a token exists (does not re-verify — server validates on each req)
export function hasSession() {
  return Boolean(getToken());
}

// ── Clear session ─────────────────────────────────────────────────────────────
export function clearSession() {
  sessionStorage.removeItem(SESSION_KEY);
}

// ── Build Authorization header object ────────────────────────────────────────
export function authHeader() {
  const token = getToken();
  if (!token) return {};
  return { Authorization: `Bearer ${token}` };
}

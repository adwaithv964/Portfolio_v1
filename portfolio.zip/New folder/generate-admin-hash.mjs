/**
 * generate-admin-hash.mjs
 * Run once with: node generate-admin-hash.mjs
 * Generates a PBKDF2-SHA256 hash of the admin password.
 * Copy the output into your .env file.
 */

import { pbkdf2, randomBytes } from 'crypto';
import { promisify } from 'util';

const pbkdf2Async = promisify(pbkdf2);

const PASSWORD = 'J#F]RkBey3YH#*eu';
const ITERATIONS = 310000;
const KEY_LENGTH = 32;
const DIGEST = 'sha256';

const salt = randomBytes(32);
const hash = await pbkdf2Async(PASSWORD, salt, ITERATIONS, KEY_LENGTH, DIGEST);

console.log('\n✅ PBKDF2 Hash generated. Copy the following into your .env file:\n');
console.log(`VITE_ADMIN_SALT=${salt.toString('hex')}`);
console.log(`VITE_ADMIN_HASH=${hash.toString('hex')}`);
console.log(`VITE_ADMIN_ITERATIONS=${ITERATIONS}`);
console.log('\n⚠️  Delete this script after use. Never commit .env to git.\n');
